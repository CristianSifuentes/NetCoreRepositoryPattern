class Carta:
    def __init__(self, nivel,tipo,ruta):
        self.tipo=tipo
        self.nivel=nivel
        self.ruta=ruta





