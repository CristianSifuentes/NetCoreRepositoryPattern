class Jugador:
    def __init__(self,nombre):
        self.nombre=nombre
        self.nivel=0
        self.jugada=""
        self.lista=[]
        self.diccn={}
    


