# Poker-Python-Game


This is a Poker game developed in Python. You can play in teams of 1-5 players. To run the game you need Python 2.7 and the package pygame.


Example
![alt tag](https://github.com/danydenio/Poker-Python-Game/blob/master/example.png)
![alt tag](https://github.com/danydenio/Poker-Python-Game/blob/master/example2.png)
![alt tag](https://github.com/danydenio/Poker-Python-Game/blob/master/example3.png)
![alt tag](https://github.com/danydenio/Poker-Python-Game/blob/master/example4.png)
![alt tag](https://github.com/danydenio/Poker-Python-Game/blob/master/example5.png)
![alt tag](https://github.com/danydenio/Poker-Python-Game/blob/master/example6.png)

